﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nave : MonoBehaviour {

    Vector3 pos;
    float vel;
    public GameObject disparos;
    Vector3 velocidad = new Vector3(0.0f, 10.0f);
    // Use this for initialization
    void Start () {
        pos = new Vector3(0.0f, 0.0f, 0.0f);
        vel = 15.0f;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Vector3 posIni = GameObject.Find("Galaga").transform.position;
            Instantiate(disparos, posIni, Quaternion.identity);
            GameObject.Find("disparos(Clone)").GetComponent<Rigidbody2D>().velocity = velocidad;
            GameObject.Find("disparos(Clone)").name = "disparo1";
        }
        pos.x = 0;
        pos.y = 0;
        if (Input.GetKey(KeyCode.RightArrow))
        {
            pos.x = vel* Time.deltaTime;
            transform.Translate(pos);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            pos.x = -vel * Time.deltaTime;
            transform.Translate(pos);
        }
        

	}
}
