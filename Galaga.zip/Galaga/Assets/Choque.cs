﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System;

public class Choque : MonoBehaviour {
    Enemigos cantidad;
    public Text score;
	// Use this for initialization
	void Start () {
        cantidad = GameObject.Find("Main Camera").GetComponent<Enemigos>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (this.gameObject.name=="Limite" && collision.gameObject.name == "disparo1")
        {
            Destroy(collision.gameObject);
        }
        if (this.gameObject.name=="enemigos(Clone)" &&  collision.gameObject.name== "disparo1")
        {
            Destroy(collision.gameObject);
            cantidad.cantidad--;
            cantidad.score = cantidad.score + 100;
            Destroy(this.gameObject);
            score.text = (Int32.Parse(score.text) + 100).ToString();
        }
    }
}
