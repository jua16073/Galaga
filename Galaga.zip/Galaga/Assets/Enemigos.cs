﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemigos : MonoBehaviour {
    public int cantidad;
    public GameObject enemigo;
    Vector3 pos = new Vector3(-7.0f, 4.0f, 0.0f);
    public int score;
    public Text scores;

	// Use this for initialization
	void Start () {
        cantidad = 0;
	}
	
	// Update is called once per frame
	void Update () {
        pos.x = -7.0f;
        pos.y = 4.0f;
        if (cantidad == 0)
        {
            while (cantidad < 14)
            {
                while (pos.y > 0)
                {
                    while (pos.x < 7)
                    {
                        Instantiate(enemigo, pos, Quaternion.identity);

                        pos.x = pos.x + 2;
                        cantidad++;
                    }
                    pos.y = pos.y - 2;
                    pos.x = -7;
                }
            }
        }
        Debug.Log(cantidad);

        scores.text = score.ToString();
	}

}
